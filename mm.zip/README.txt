# For Mercado Libre Workers — Product Showcase

A static, read-only catalog with 131 sample products. It contains no login, registration, cart, checkout, payment, database, or backend. Product names and prices are illustrative. This is not an official Mercado Libre website.

## Preview on your computer
1. Extract the ZIP file.
2. Open `index.html` in Chrome, Edge, or Firefox.

## Publish a public link with GitHub Pages
1. Sign in at https://github.com/ and create a new repository, for example `product-showcase`.
2. Upload `index.html` and `.nojekyll` to the repository's top level (not inside another folder).
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then press **Save**.
6. Wait a few minutes and refresh the Pages settings. GitHub will show your public website URL, usually `https://YOUR-USERNAME.github.io/product-showcase/`.

The public URL depends on your GitHub username and repository name, so it cannot be generated until you publish it. For official instructions see https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
